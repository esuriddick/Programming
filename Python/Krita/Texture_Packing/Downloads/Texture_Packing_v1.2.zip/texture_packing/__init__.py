from .texture_packing import texture_packing

Krita.instance().addExtension(texture_packing(Krita.instance()))